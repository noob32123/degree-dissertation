# MDPI major revision source package

- manuscript.tex: clean manuscript source
- manuscript_marked.tex: highlighted source, generated from the same source with ShowRevisions enabled
- manuscript_clean.pdf: clean manuscript
- manuscript_marked.pdf: highlighted manuscript
- ref.bib, Definitions/, generated/, figures/, fig1.jpg, fig2.jpg: compilation dependencies

Compile with XeLaTeX or Tectonic from this directory. The marked source starts with `\\def\\ShowRevisions{1}`.
